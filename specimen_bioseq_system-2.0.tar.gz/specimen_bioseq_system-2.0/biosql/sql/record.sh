psql biosql < biosqldb-pg.sql
