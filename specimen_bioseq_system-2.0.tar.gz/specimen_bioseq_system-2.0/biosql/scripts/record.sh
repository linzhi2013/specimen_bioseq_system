perl load_ncbi_taxonomy.pl --dbname biosql --driver Pg --dbuser postgres
